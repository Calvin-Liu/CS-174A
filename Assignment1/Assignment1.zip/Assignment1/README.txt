Calvin Liu
Mac Computer
Google Chrome Browser

Completed the sierpinski gasket
Was able to pass color variable to fragment shader
Was able to make it change colors through the key ‘C’
Was able to make it rotate
Not able to make another fractal and switch between them
