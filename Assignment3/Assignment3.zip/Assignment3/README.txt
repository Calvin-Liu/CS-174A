Calvin Liu
804182525

Implemented the solar system and the navigation system works fine
I implemented the moon for extra credit
The planets are different colors and there is some traces of lighting but it is not as apparent compared to others who have implemented it where the other side of the sun is all dark. You can see the lighting better if you zoom in with i
The rotation of the planets work fine and replicates the orbit

i - forward
m - backward
j - left
k - right
up - higher angle
r - reset
down - lower angle
right - rotate right
left - rotate left 

