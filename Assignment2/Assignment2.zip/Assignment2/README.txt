Common files:

webgl-utils.js: standard utilities from google to set up a webgl context

MV.js: our matrix/vector package. Documentation on website

initShaders.js: functions to initialize shaders in the html file

initShaders2.js: functions to initialize shaders that are in separate files

Calvin Liu
804182525

Space bar changes color instead of c
c makes a orthographic cross appear
r resets everything
w makes the scene wider
n makes the scene narrower
up arrow translates cubes down
down arrow translates cubes up
j translates cubes left
k translates cubes right
i moves cubes foward
m moves cubes back

2 Extra credits implemented except the triangle strip one. 

Could not get left and right working perfectly